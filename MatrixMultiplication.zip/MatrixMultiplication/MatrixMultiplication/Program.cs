﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

class Program 

{
    static int dim = 100;

    static void Main(String[] args)
    {
        var matrizA = new int[dim, dim];
        var matrizB = new int[dim, dim];
        Random random = new Random();

        for (int i = 0; i < dim; i++)
        {
            for (int j = 0; j < dim; j++)
            {
                matrizA[i, j] = random.Next(1, dim);
                matrizB[i, j] = random.Next(1, dim);

            }
        
        }

        //Version secuencial

        Console.WriteLine("Iniciar Version Secuencial");
        //Iniciar temporizador
        Stopwatch sws = Stopwatch.StartNew();

        //Llamar al metodo de multiplicacion secuencial
        multiplicacionSecuencial(matrizA, matrizB);

        //Finalizar temporizador
        sws.Stop();

        //Asignar tiempo a una variable
        long tiempoSecuencial = sws.ElapsedMilliseconds;
        Console.WriteLine($"Tiempo secuencial: {tiempoSecuencial}");


        //Version Paralela
        Console.WriteLine("\nIniciando Version Paralela");

        //Crear lista de procesadores
        List<int> numProcesadores = new List<int>() { 2, 4, 6 };

        //Recorrer lista de procesadores
        foreach (int procesadores in numProcesadores) 
        {
            //Iniciar tiempo paralelo
            Stopwatch swp = Stopwatch.StartNew();

            //Llamar a la funcion multiplicacion paralela
            multiplicacionParalela(matrizA, matrizB, procesadores);

            //Detener tiempo paralelo
            swp.Stop();

            //Asignar tiempo a una variable
            long tiempoParalelo = swp.ElapsedMilliseconds;

            //Calcular el Speedup
            double aceleracion = (double)tiempoSecuencial / tiempoParalelo;

            //Calcular la eficiencia
            double eficiencia = (aceleracion / procesadores) ;

            // Mostrar informacion
            Console.WriteLine($"\nNumero de procesadores: {procesadores}");
            Console.WriteLine($"Tiempo Paralelo: {tiempoParalelo}ms");
            Console.WriteLine($"Speedup: {aceleracion:F2}");
            Console.WriteLine($"Eficiencia: {eficiencia:F2}%");

        }



    }

    //Metodo de multiplicacion Secuencial
    static int[,] multiplicacionSecuencial(int[,] matrizA, int[,] matrizB) 
    {
        var resultado = new int[dim, dim];

        for (int i = 0; i < dim; i++) 
        {
            for (int j = 0; j < dim; j++) 
            {
                int suma = 0;

                for (int k = 0; k < dim; k++) 
                {
                    suma += matrizA[i, k] * matrizB[k, j];
                
                }

                resultado[i, j] = suma;
                
            }

        
        }
        return resultado;
    
    }

    //Metodo de multiplicacion Paralela
    static int[,] multiplicacionParalela(int[,] matrizA, int[,] matrizB, int procesadores)
    {
        var resultado = new int[dim, dim];

        Parallel.For(0, dim, new ParallelOptions { MaxDegreeOfParallelism = procesadores }, i =>
        {
            for (int j = 0; j < dim; j++)

            {
                int suma = 0;

                for (int k = 0; k < dim; k++)
                {
                    suma += matrizA[i, k] * matrizB[k, j];

                }
                resultado[i,j] = suma;
            }

        });

        return resultado;
    }

} 

