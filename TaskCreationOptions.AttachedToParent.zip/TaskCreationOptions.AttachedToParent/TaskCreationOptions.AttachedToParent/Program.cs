﻿
using System; 
using System.Threading.Tasks;
class Program
{
    static async Task Main()
    {
        Console.WriteLine("!Bienvenidos a la preparacion de la ensalada de frutas!");

        //Tarea principal padre
        Task preparacionEnsalada = Task.Factory.StartNew( () =>
        {
            Console.WriteLine("Inicio de la preparacion de la ensalada de frutas");

            //Tarea hija 1
            Task.Factory.StartNew( () =>
            {
                Console.WriteLine("Pelar las frutas.");
                Console.WriteLine("Frutas paladas.");
            }, TaskCreationOptions.AttachedToParent);
            

            //Tarea hija 2
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Cortar las frutas.");
                Console.WriteLine("Frutas cortadas.");
            }, TaskCreationOptions.AttachedToParent);

             //Tarea hija 3
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Mezclar las frutas");
                Console.WriteLine("Frutas mezcladas");
            }, TaskCreationOptions.AttachedToParent);

            //Tarea hija 4
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Agregar jugo de limón");
                Console.WriteLine("jugo de limón agregado.");
            }, TaskCreationOptions.AttachedToParent);

            //Tarea hija 5
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Agregar miel o azucar");
                Console.WriteLine("Agregando miel o azucar");
                Console.WriteLine("Miel agregada");
            }, TaskCreationOptions.AttachedToParent);

            //Tarea hija 6
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Servir la ensala");
                Console.WriteLine("Ensalada de frutas servida");
            }, TaskCreationOptions.AttachedToParent);

        });
        await preparacionEnsalada;
        Console.WriteLine("Tarea padre completada.");
    }
}



