﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

class Multiplicacion
{
    static void Main(string[] args)
    {
        int processor = Environment.ProcessorCount;
        Console.WriteLine($"Cantidad de procesadores disponible {processor}");
        Console.WriteLine("Bienvenidos al programa de multiplicacion de matrices");

        int dim = 100;
        var matrizA = new int[dim, dim];
        var matrizB = new int[dim, dim];
        var random = new Random();

        for (int i = 0; i < dim; i++)
        {
            for (int j = 0; j < dim; j++)
            {
                matrizA[i, j] = random.Next(1, 100);
                matrizB[i, j] = random.Next(1, 100);

            }

        }

        //Ejecucion paralela
        Console.WriteLine("Iniciar ejecucion secuencial");

        //temporizador
        Stopwatch swSecuencial = Stopwatch.StartNew();

        multiplicacionSecuencial(matrizA, matrizB);
        swSecuencial.Stop();

        long tiempoSecuencial = swSecuencial.ElapsedMilliseconds;
        Console.WriteLine($"Tiempo secuencial {tiempoSecuencial}ms");


        //Ejecucion Paralela

        List<int> numProcesadores = new List<int>() { 2, 4, 6 };

        foreach (int procesadores in numProcesadores)
        {

            //Ejecucion paralela
            Console.WriteLine("Iniciar ejecucion paralela");

            //temporizador
            Stopwatch swParalela = Stopwatch.StartNew();

            multiplicacionparalela(matrizA, matrizB, procesadores);
            swParalela.Stop();

            long tiempoParalelo = swParalela.ElapsedMilliseconds;

            //Calcular el Speedup
            double aceleracion = (double)tiempoSecuencial / tiempoParalelo;
            double eficiencia = (aceleracion / procesadores)* 100;

            //Mostrar resultados
            Console.WriteLine($"\nProcesadores:.{procesadores}");
            Console.WriteLine($"Tiempo paralelo:.{tiempoParalelo}ms");
            Console.WriteLine($"Speedup:. {aceleracion:F2}");
            Console.WriteLine($" Eficiencia:. {eficiencia:F2}");

        }


    }


    static int[,] multiplicacionSecuencial(int[,] matrizA, int[,] matrizB)
    {
        var resultado = new int[100, 100];
        for (int i = 0; i < 100; i++)
        {       
            for (int j = 0; j < 100; j++)
            {
                int suma = 0;
                for (int k = 0; k < 100; k++)
                {
                    suma += matrizA[i, k] * matrizB[k, j];
                }
                resultado[i, j] = suma;

            }
        }
        return resultado;
    }

    static int[,] multiplicacionparalela(int[,] matrizA, int[,] matrizB, int procesadores)
    {
        var resultado = new int[100, 100];

       
        
            Parallel.For(0, 100, new ParallelOptions { MaxDegreeOfParallelism = procesadores }, i =>
            {
                for (int j = 0; j < 100; j++)
                {
                    int suma = 0;
                    for (int k = 0; k < 100; k++)
                    {
                        suma += matrizA[i, k] * matrizB[k, j];
                    }
                    resultado[i, j] = suma;

                }

            });
        

        return resultado;
    }


}


