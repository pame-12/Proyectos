﻿using System;
using System.Threading.Tasks;
class Program
{
    static async Task Main()
    {
        Task task = await Task.Factory.StartNew(async () =>
        {
            Console.WriteLine("Tarea principal ejecutándose.");
            await Task.Delay(1000);
            Console.WriteLine("Tarea principal terminada.");

        });

        // Tarea hermana
        Task tareaHermana = Task.Run(async () =>
        {
            await task; // Espera que la tarea principal termine.
            Console.WriteLine("Tarea hermana ejecutándose después de la principal.");
            
            Console.WriteLine("Tarea hermana ejecutada");
        });
        await tareaHermana;
         

        task.ContinueWith(t =>
        {
            Console.WriteLine("Tarea de continuación que se ejecute en después de la tarea principal");
        });
        await task;

        //Se ejecuta tan pronto termine la tarea principal y puede estar en ejecución paralela con los demás hijos. 
        task.ContinueWith(t =>
        {
            Console.WriteLine("Tarea0 de continuación ejecutándose.");
        });

        //Se ejecuta tan pronto termine la tarea principal de manera sincrónica con la tarea principal. 
        await task.ContinueWith(t =>
        {
            Console.WriteLine("Tarea1 de continuación ejecutándose.");
        });

        //Se ejecuta mientras la tarea principal se está ejecutando sin errores y sincrónica con la tarea predecesora. 
        await task.ContinueWith(t =>
        {
            Console.WriteLine("Tarea2 de continuación ejecutándose.");
        }, TaskContinuationOptions.OnlyOnRanToCompletion);
    }
}