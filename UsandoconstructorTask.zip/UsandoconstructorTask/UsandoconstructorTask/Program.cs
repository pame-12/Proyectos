﻿using System;
using System.Threading.Tasks;
using static System.Console;
class Program
{
    static void Main()
    {

        Task<int> SumaTask = new Task<int>(() =>
        {
            WriteLine("Iniciando Tarea de suma de numeros:");
            WriteLine("Ingresa un numero hasta donde quieras sumar");
            string entrada = ReadLine();
            int numero = int.Parse(entrada);
            int Suma = 0;
            for (int i = 1; i <= numero; i++)
            {
                Suma += i;
            }
            WriteLine($"La suma de los numeros es de 1 hasta {numero}: {Suma}");
            return Suma;

        });



        Task<int> FactorialTask = new Task<int>(() =>
        {
            WriteLine("Iniciando Tarea de Factorial de numeros:");
            WriteLine("Ingresa un numero para ver su factorial");
            string Entrada = ReadLine();
            int Numero = int.Parse(Entrada);
            int Factorial = 1;
            for (int i = 1; i <= Numero; i++)
            {
                Factorial *= i;
            }
            WriteLine($"El factorial del {Numero} es: {Factorial}");
            return Factorial;

        });

        SumaTask.Start();
        SumaTask.Wait();
        FactorialTask.Start();
        FactorialTask.Wait();
        


        int resultado = SumaTask.Result + FactorialTask.Result;
        WriteLine($"La suma del resultado final de todas las operaciones es {resultado}");
        WriteLine("Fin del programa.");

    }
}

