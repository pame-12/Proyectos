// Obtener todos los cuadros con la clase "letra"
const letras = document.querySelectorAll('.letra');

// Función para mostrar el mensaje con el significado al hacer clic
letras.forEach(letra => {
    letra.addEventListener('click', function() {
        const significado = letra.getAttribute('data-significado');
        document.getElementById('mensaje').textContent = significado;
    });
});
