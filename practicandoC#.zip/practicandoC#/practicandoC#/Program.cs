﻿
/*using System;
using System.Diagnostics;

class Program
{
    static void Main()
     {
         // Console.WriteLine("Aprendiendo c# parte 1");
         //saludar();
         //Console.WriteLine("Aprendiendo c# parte 2 variables");
         //variables();

         //Console.WriteLine("Aprendiendo c# parte 2 condicionales");
         //condicionales();

         //Console.WriteLine("Aprendiendo c# parte 2 condicionales");
         //ciclicas();

         Console.WriteLine(Sumar(2, 3));

     }


     static void saludar()
     {
         Console.WriteLine("Cual es tu nombre");
         string nombre = Console.ReadLine();
         Console.WriteLine($"Hello!!! {nombre}");
     }


     static void variables()
     {
         // declarar variables 
         int numero = 12;
         char letra = 'A';
         string palabra = "Pamela";
         bool esVerdadero = true;
         float flotante = 3.14f;
         double decima = 3.14;
         var auto = "Varibleautomatica";

         Console.WriteLine("Los valores de las variables declaradas son:");
         Console.WriteLine($"Numero:{numero}");
         Console.WriteLine($"letra:{letra}");
         Console.WriteLine($"palabra:{palabra}");
         Console.WriteLine($"Boolean:{esVerdadero}");
         Console.WriteLine($"float:{flotante}");
         Console.WriteLine($"double:{decima}");
         Console.WriteLine($"auto:{auto}");


     }

     static void condicionales()
     {
         Console.WriteLine("Ingresa un numero");
         int x = int.Parse(Console.ReadLine());

         if (x > 0)
         {
             Console.WriteLine("el numero es positivo");
         }

         else if (x < 0)
         {
             Console.WriteLine(" El numero es negativo");

         }

         else 
         { 
         Console.WriteLine("Es cero");
         }

     }

     static void ciclicas()
     {
         Console.WriteLine("Introduce un dia equivalente a un dias de la semana");
         int n = int.Parse(Console.ReadLine());

         switch (n) 
         { 
             case 1:
                 Console.WriteLine("Lunes");
                 break;

             case 2:
                 Console.WriteLine("Martes");
                 break;

             default:
                 Console.WriteLine("Otro dia");
                 break;
         }

         Console.WriteLine("Usando for");

         for (int i = 0; i < 5; i++)
         {
             Console.WriteLine("Estudia mucho");
         }

         Console.WriteLine("while");
         int c = 0;

         while (c < 5)
         {
             Console.WriteLine("Estudia mucho2");
             c++;
         }


         Console.WriteLine("Usando do-while");
         int j = 0;
         do
         {
             Console.WriteLine("Estudia mucho3");
             j++;
         }while (j < 10);



         Console.WriteLine("Usando foreach");

         int[] numeros= { 1, 2, 3, 4, 5, 6, 7 };

         foreach (int i in numeros)
         { 
         Console.WriteLine(i);
         }


     }

     static int Sumar(int a, int b) 
     { 
     int suma = 0;
         suma = a + b;
         return suma;

     }
 }


     */



using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

class Program
{

    static void Main(string[] args) 
    {

        // Para ver el numero de procesadores

        int processors = Environment.ProcessorCount;
        Console.WriteLine($"Numero de procesadores disponibles: {processors}");
        Console.WriteLine();

        Console.WriteLine("======================================================");
        Console.WriteLine("Tarea de programacion paralela");
        Console.WriteLine("======================================================");
        Console.WriteLine("\n En este programa vamos a trabajar con 2 tipos de descomposicion paralela en c# ");

        // cliclo infinito
        while (true)
        {
            Console.WriteLine("\nSeleccione el tipo de descompocicion que quiere probar");
            Console.WriteLine("1. Descompocicion de datos");
            Console.WriteLine("2. Descomposicion explorativa");
            Console.WriteLine("3. salir");

            // int.parse
            int option = int.Parse( Console.ReadLine() );

            switch (option) 
            {
                case 1:
                    DescomposicionDeDatos();
                    break;
                case 2:
                    DescomposicionExplorativa();
                    break;
                case 3:
                    Console.WriteLine("Saliendo del programa");
                    return;

                default:
                    Console.WriteLine("Opcion no validad, intentelo denuevo");
                    break;


            }

        }

        // Ejercicio I. Descomposicion de datos
        static void DescomposicionDeDatos()
        {
            // Limpiar la pantalla
            Console.Clear();
            Console.WriteLine("************************************************");
            Console.WriteLine("Ejercio de Descomposicion de datos");
            Console.WriteLine("************************************************");
            Console.WriteLine("En este ejemplo vamos a simular la limpiza de 1000 peces usando descomposicion de datos");

            int totalPeces = 1000;

            //Ejecutar la version secuencial
            Console.WriteLine("Ejecutando version secuencial....");

            // Crear una variable e iniciar el cronometro
            Stopwatch swSecuencial = Stopwatch.StartNew();

            // Vesion secuencial 
            LimpiarPecesSecuencial(totalPeces);

            //Finalizae cronometro
            swSecuencial.Stop();

            long tiempoSecuncial = swSecuencial.ElapsedMilliseconds;
            Console.WriteLine($"Tiempo secuencial:{tiempoSecuncial}ms ");

            //ejecucion de la version paralela con diferentes numeros de procesadores
            Console.WriteLine("\n Ejecutando version paralela....");

            //crear una lista con diferentes numeros de procesadores
            List<int> numProcesadores = new List<int>() { 2, 4 };

            foreach (int numProc in numProcesadores)
            {
                //Iniciar temporizador
                Stopwatch swParalela = Stopwatch.StartNew();

                //Version paralela
                LimpiarPecesParalelo(totalPeces, numProc);

                //Finalizar temporizador
                swParalela.Stop();


                long tiempoParalelo = swParalela.ElapsedMilliseconds;


                // calcular speedup
                double aceleracion = (double)tiempoSecuncial / tiempoParalelo;
                // calcular la aceleracion
                double eficiencia = (aceleracion / numProc) * 100;

                Console.WriteLine($"\n Con: {numProc} pescadores (procesadores): ");
                //Mostrar el tiempo paralelo
                Console.WriteLine($"Tiempo paralelo {tiempoParalelo}ms");
                //Mostrar el speedup
                Console.WriteLine($"Aceleracion (Speedup): {aceleracion:F2}");
                //Mostrar eficiencia
                Console.WriteLine($"Eficiencia:{eficiencia:F2}% ");

            }

            Console.WriteLine("\nPresione enter para continuar");
            Console.ReadLine();


        }

        static void LimpiarPecesSecuencial(int totalPeces)
        {
            for (int i = 0; i < totalPeces; i++)
            { 
             Thread.Sleep(1);
            }

        }

        static void LimpiarPecesParalelo(int totalPeces, int numProcesadores)
        {
            Parallel.For(0, totalPeces, new ParallelOptions { MaxDegreeOfParallelism = numProcesadores }, i =>
            {
                Thread.Sleep(1);

            });
        }

        // Ejercicio II Descomposicion explorativa
        static void DescomposicionExplorativa()
        {
            Console.Clear();
            Console.WriteLine("Ejercicio 2. descomposicion explorativa");
            Console.WriteLine("============================================================================");
            Console.WriteLine("En este ejercio vamos a encontrar un tesoro dentro de un area total");
            Console.WriteLine("============================================================================");

            //Hacer una intancia de la variable ramdom
            Random random = new Random();
            // Tamano del area total a explorar
            int areaTotal = 1000;
            // generar una posicion aleatoria donde estara el tesoro
            int posicionTesoro = random.Next(0, areaTotal);

            //Iniciar ejecucion secuencial
            Console.WriteLine("Iniciando ejecucion secuencial");

            Stopwatch swsecuencial = Stopwatch.StartNew();
            //Version secuencial

            BusquedaSecuencial(areaTotal, posicionTesoro);
            swsecuencial.Stop();

            //Asignar el tiempo secuencial a una variable y mostrarlo
            long tiempoSecuencial = swsecuencial.ElapsedMilliseconds;
            Console.WriteLine($"Tiempo de la busqueda secuencial {tiempoSecuencial}");

            //iniciar ejecucion paralela
            Console.WriteLine("Iniciando ejecucion Paralela");

            List<int> numBuscadores = new List<int>() { 2,4};

            foreach(int numProc in numBuscadores)
            { 
                Stopwatch swParalela = Stopwatch.StartNew();

                //version paralela
                BusquedaParalela(areaTotal, posicionTesoro, numProc);
                swParalela.Stop();

                long tiempoParalelo = swParalela.ElapsedMilliseconds;

                //calculo del speedup
                double aceleracion = (double) tiempoSecuencial / tiempoParalelo;
                double eficiencia = (aceleracion / numProc) * 100;

                //Mostrar el tiempo
                Console.WriteLine($"Numero de procesadores {numProc}");
                Console.WriteLine($"tiempo de ejecucion paralela: {tiempoParalelo}ms");
                Console.WriteLine($"Aceleracion: {aceleracion:F2}");
                Console.WriteLine($"eficiencia: {eficiencia:F2}%");
            }

            Console.WriteLine(" Presione enter para continuar");
            Console.ReadLine();


        }

        static void BusquedaSecuencial(int areTotal, int posicionTesoro )
        {
            for (int i=0; i<areTotal; i++) 
            {
                Thread.Sleep(1);
                if (i == areTotal)
                {
                    Console.WriteLine($"El tesoro ha sido encontrado en la posicion{i}");
                }

            }
        }

        static void BusquedaParalela(int areTotal, int posicionTesoro, int numBuscadores)
        {
            int tamañoSeccion = areTotal / numBuscadores;
            CancellationTokenSource cts = new CancellationTokenSource();
            object bloque = new object();
            bool encontrado = false;

            try
            {
                Parallel.For(0, numBuscadores, new ParallelOptions { CancellationToken = cts.Token }, (buscador) =>
                {
                    int inicio = buscador / areTotal;
                    int fin = (numBuscadores == buscador-1) ? areTotal : inicio + tamañoSeccion;

                    for (int i = 0; i < fin; i++)
                    {
                        Thread.Sleep(1);

                        if (i == posicionTesoro)
                        {

                            lock (bloque)
                            {
                                if (!encontrado)
                                {
                                    encontrado = true;
                                    Console.WriteLine($"El tesoro a sido encontrado por el buscador {buscador} eun la posicion{i}");
                                    cts.Cancel();
                                }

                            }
                            return;
                        }

                    }



                });

            }

            catch (OperationCanceledException ex)
            { 
            Console.WriteLine($"Operacion cancelada"+ ex.Message);
            }
        }

    }

}




