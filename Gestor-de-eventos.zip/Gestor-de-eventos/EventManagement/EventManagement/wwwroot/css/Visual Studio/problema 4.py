# Problema 4: Decoración de interiores 🖼️

'''Eres un decorador de interiores y te gustaría usar Python para simplificar parte de tu trabajo. 
Específicamente, está creando una herramienta que pretende usar para calcular el costo de pintar una habitación.

Como primer paso, defina una función get_cost() que tome como entrada:

sqft_walls = total de pies cuadrados de paredes a pintar
sqft_ceiling = pies cuadrados de techo a pintar
sqft_per_gallon = número de pies cuadrados que puede cubrir con un galón de pintura
cost_per_gallon = costo (en dólares) de un galón de pintura
Debe devolver el costo (en dólares) de poner una capa de pintura en todas las paredes y el techo. 
Suponga que puede comprar la cantidad exacta de pintura que necesita, por lo que puede comprar galones
parciales (por ejemplo, si necesita 7,523 galones, puede comprar esa cantidad exacta, en lugar de necesitar 
comprar 8 galones y desperdiciar algo de pintura). No redondee su respuesta.'''


# definición de la función
def get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):

  #calcular el area total a pintar
  area_total = sqft_walls + sqft_ceiling

  #calculas la cantidad de galones necesarios
  galones_necesarios = area_total / sqft_per_gallon

  # Calcular el costo total
  cost = galones_necesarios * cost_per_gallon
  return cost

# Datos de ejemplo
sqft_walls = 432
sqft_ceiling = 144
sqft_per_gallon = 400
cost_per_gallon = 15

# Asigna a la variable project_cost el costo del proyecto
project_cost = get_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon)

# Imprime el costo del proyecto
print("El costo total de poner una capa de pintura en todas las paredes y el techo es:", project_cost)

'''Ahora digamos que ya no puede comprar fracciones de un galón. 
(Por ejemplo, si necesita 4.3 galones para hacer un proyecto, entonces tiene que comprar 5 galones de pintura).
Con este nuevo escenario, creará una nueva función get_actual_cost que usa las mismas entradas y calcula el costo 
de su proyecto.Deberá usar la función math.ceil() para hacer esto.'''


#funcion para obtener el costo sin redondear 
import math
def get_actual_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon):
  #calcular el area total a pintar
  area_total = sqft_walls + sqft_ceiling

  #calculas la cantidad de galones necesarios
  galones_necesarios = math.ceil(area_total / sqft_per_gallon)

  # Calcular el costo
  cost = galones_necesarios * cost_per_gallon
  return cost

# Datos de ejemplo
sqft_walls = 432
sqft_ceiling = 144
sqft_per_gallon = 400
cost_per_gallon = 15

# Asigna a la variable project_cost el costo del proyecto
cost = get_actual_cost(sqft_walls, sqft_ceiling, sqft_per_gallon, cost_per_gallon)

# Imprime el costo del proyecto
print("El costo total de poner una capa de pintura en todas las paredes y el techo es:", cost )

