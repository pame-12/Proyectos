
# Problema 5: Reporte estadístico 📊

''' Escribir una función que reciba una muestra de números en una lista y devuelva un diccionario conteniendo las siguientes características:

Tamaño de la muestra
Valor máximo
Valor mínimo
Suma de valores
Media
Rango
Varianza
Desviación estándar
Coeficiente de variación
Lista de valores atípicos (aquellos con puntuación z mayor a 3 y menor a -3)
Su programa deberá seguir las siguientes características:

Aplique la descomposición, desarrollando y utilizando funciones para los siguientes estadísticos:

Media (avg)
Rango (rng)
Varianza (var)
Desviación estándar (std)
Coeficiente de variación (cv)
Valores atípicos (outliers)
La función principal deberá también presentar un reporte por consola mostrando los datos que recibió y los estadísticos calculados.'''

import math

#funcion para calcular la media
def media(datos):
  return sum(datos)/len(datos)

#funcion para calcular el rango
def rango(datos):
  return max(datos) - min(datos)

#funcion para calcular la varianza
def varianza(datos):
  prom = media(datos)
  return sum((x-prom ) ** 2 for x in datos) / (len(datos))

#funcion para calcular la desviacion estandar
def desviacion_estandar(datos):
  return math.sqrt(varianza(datos))

#funcion para calcular el coeficiente de variacion
def coeficiente_variacion(datos):
  return (desviacion_estandar(datos) / media(datos)) * 100

#funcion para identificar valores atipicos
def valores_atipicos(datos):
  prom = media(datos)
  desviacion = desviacion_estandar(datos)
  return [x for x in datos if abs(x - prom) / desviacion > 3]

#funcion principal
def calcular_estadisticas(datos):
  # Calcula cada estadístico utilizando las funciones definidas
  estadisticas = {
        "Tamaño de la muestra": len(datos),
        "Valor máximo": max(datos),
        "Valor mínimo": min(datos),
        "Suma de valores": sum(datos),
        "Media": media(datos),
        "Rango": rango(datos),
        "Varianza": varianza(datos),
        "Desviación estándar": desviacion_estandar(datos),
        "Coeficiente de variación": coeficiente_variacion(datos),
        "Valores atípicos": valores_atipicos(datos),
    }

  # Imprime el reporte en consola
  print("Datos recibidos:", datos)
  print("Estadísticas calculadas:")
  for clave, valor in estadisticas.items():
    print(f"{clave}: {valor}")

  return estadisticas

# Ejemplo de uso
muestra = [10, 20, 30, 40, 50, 60]
estadisticas = calcular_estadisticas(muestra)
