# Problema 1: Purple Shell 🚗🚓🚙💨

'''Desarrolle una función purple_shell() que reciba como entrada una lista con los personajes 
del juego en el orden en que se encuentran en la carrera y devuelva el nuevo orden de los personajes tras 
aplicar el efecto Purple Shell.'''

# definir funcion Purple Shell
def purple_shell(jugadores):
    # Verifica que haya al menos dos jugadores para hacer el intercambio
    if len(jugadores) < 2:
        return jugadores

    # Intercambia el primer y último elemento
    jugadores[0], jugadores[-1] = jugadores[-1], jugadores[0]

    return jugadores

# Lista inicial de jugadores en el orden de la carrera
jugadores_inicial = ["Mario", "Bowser", "Luigi"]
print('Lista de jugadores iniciales')
print(jugadores_inicial)

# Aplicar el efecto Purple Shell
jugadores_actualizados = purple_shell(jugadores_inicial)
print('\nLista de jugadores actualizados')
print(jugadores_actualizados)
