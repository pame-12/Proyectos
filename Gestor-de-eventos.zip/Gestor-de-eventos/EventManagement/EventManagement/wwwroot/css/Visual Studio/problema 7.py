
# Problema 7: Tragamonedas 🎰


import random

#funcion jugar_tragamonedas
def jugar_tragamonedas():
    r = random.random()
    if r < .005:
        return 100
    elif r < .05:
        return 5
    elif r < .25:
        return 1.5
    else:
        return 0

jugar_tragamonedas()

'''Complete la siguiente función para calcular el valor promedio por jugada de la máquina tragamonedas'''

#función para calcular el valor promedio por jugada de la máquina tragamonedas
def estimar_ganancia_promedio_tragamonedas(intentos):

  # Acumular la ganancia neta total
  ganancia_total = 0

  # Realizar la cantidad de intentos especificada
  for i in range(intentos):
    ganancia = jugar_tragamonedas() -1
    ganancia_total += ganancia

  #calcular el promedio de ganancias netas por intentos
  ganancia_promedio = ganancia_total / intentos
  return ganancia_promedio

# Ejemplo de uso
estimacion = estimar_ganancia_promedio_tragamonedas(500)
print('Estimacion de la ganancia promedio por jugada', estimacion)