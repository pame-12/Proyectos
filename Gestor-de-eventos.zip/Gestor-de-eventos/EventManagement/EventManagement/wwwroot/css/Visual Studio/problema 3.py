
# Problema 3: Lorem ipsum 📜

'''Desarrolle un programa que analice dicho pasaje y presente las siguientes estadísticas del texto en pantalla:

Número de caracteres.
Número de letras.
Número de palabras.
Número de oraciones.
Enlistar todas las palabras distintas que contiene el texto (sin incluir signos de puntuación ni espacios).
Número de palabras distintas.
Su programa se probará con el Lorem ipsum, pero debe funcionar bien para cualquier texto.'''


#funcion para analizar texto
def analizar_texto(texto):
  #numero de caracteres
  numero_caracteres = len(texto) #len calcula la longitud total del texto

  #numero de letras
  numero_letras= sum(1 for char in texto if char.isalpha()) #isalpha es para sumar solo los caracteres alfabeticos

  #numero de palabras
  palabras = texto.split() #split divide el texto en palabras, que separa en espacios en blanco
  numero_palabras = len(palabras)

  #Numero de oraciones
  numero_oraciones = sum(1 for char in texto if char in ".!?")

  # Enlistar todas las palabras distintas sin signos de puntuación
  palabras_limpias = [palabra.strip(string.punctuation).lower() for palabra in palabras] #strip(string.punctuation) elimina cualquier signo de puntuación de las palabras
  palabras_distintas = set(palabras_limpias)

  #Número de palabras distintas.
  numero_palabras_distintas = len (palabras_distintas)

  # Imprimir resultados
  print("Número de caracteres:", numero_caracteres)
  print("Número de letras:", numero_letras)
  print("Número de palabras:", numero_palabras)
  print("Número de oraciones:", numero_oraciones)
  print("Palabras distintas:", palabras_distintas)
  print("Número de palabras distintas:", numero_palabras_distintas)

# Texto de ejemplo
texto = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt\
 ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco \
laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in \
voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\
 proident, sunt in culpa qui officia deserunt mollit anim id est laborum."

# Llamar a la función con el texto de ejemplo
analizar_texto(texto)

