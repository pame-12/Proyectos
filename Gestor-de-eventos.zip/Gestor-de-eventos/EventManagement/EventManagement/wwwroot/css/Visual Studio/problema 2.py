import math

# Problema 2: Una clase desde cero 📈
''' Usted es un desarrollador de Python escribiendo un paquete de visualización. Para cualqueir elemento de la visualización, 
quiere poder decir la posición del elemento, qué tan lejos se encuentra de otros elementos, e implementar facilmente la inversión vertical y horizontal.

El elemento más básico de cualquier visualización es un punto. Escriba una clase para un punto en el plano, con las siguientes características:

El nombre de la clase es Punto.
Los atributos x e y son las coordenadas del punto en el plano.
Un constructor que acepta las coordenadas x e y e inicializa los atributos correspondientes. Por defecto estos argumentos deben tener valor de 0.0.
Un método distancia_al_origen() que devuelva la distancia euclidea del punto al origen.
Un método invertir() que invierta el punto con respecto al eje x o y:
Acepta un argumento eje.
Si eje = "x", cambia el signo del atributo y.
Si eje = "y", cambia el signo del atributo x.
Para cualquier otro valor de eje, imprima in mensaje de error.'''


#declarar la clase punto
class punto:
  def __init__(self, x=0.0, y=0.0): #Inicializar los atributos correspondiente
    self.x = x
    self.y = y

  #Funcion que calcula la distancia euclideana al origen
  def distancia_al_origen(self):
    return math.sqrt(self.x**2 + self.y**2)

  #Funcion que invierte segun el eje dado
  def invertir(self, eje):
    # si el eje es x intercambia el signo de y
    if eje == "x":
      self.y = -self.y
    # si el eje es y intercambia el signo de x
    elif eje == "y":
      self.x = -self.x
    #si no es x ni y imprime un mensaje de error
    else:
      print("Error: El eje debe ser 'x' o 'y'.")

#Ejemplo de uso
punto1 = punto(3, 4)
print("Distancia al origen: ", punto1.distancia_al_origen())

#Invertir respecto al eje x
punto1.invertir("x")
print('Despues de invertir', (punto1.x, punto1.y))

#Invertir respecto al eje y
punto1.invertir("y")
print('Despues de invertir', (punto1.x, punto1.y))

#Invertir un eje no valido
punto1.invertir("z")

