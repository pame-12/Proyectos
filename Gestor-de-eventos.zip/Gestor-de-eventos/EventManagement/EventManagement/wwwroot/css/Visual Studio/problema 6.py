
# Problema 6: Precios de viviendas 🏠

'''Cuando se desea estimar precios de vivienda, se debe utilizar información como el número de 
habitaciones y baños para predecir el precio de una vivienda. Escribirá su propia función para hacer esto.

En la siguiente celda de código, cree una función get_expected_cost() que tenga dos argumentos:

beds - número de dormitorios
baths - número de baños
Debería devolver el costo esperado de una casa con esa cantidad de dormitorios y baños. Asumir que:

El costo esperado para una casa con 0 dormitorios y 0 baños es 80000.
Cada dormitorio agrega 30000 al costo esperado
Cada baño suma 10000 al costo esperado.
Por ejemplo,

una casa de 1 dormitorio y 1 baño tiene un costo esperado de 120000
una casa de 2 dormitorios y 1 baño tiene un costo esperado de 150000.'''

# función para obtener el costo 
def get_expected_cost(beds, baths):
  # Costo base para una casa sin dormitorios y sin baños
  base_cost = 80000

  # Agregar costo por dormitorios
  cost_per_bed = beds * 30000

  # Agregar costo por baños
  cost_per_bath = baths * 10000

  # Calcular el costo total
  value = base_cost + cost_per_bed + cost_per_bath
  return value

# Ejemplo de uso
costo = get_expected_cost(2, 1)
print('costo estimado de la propiedad', costo)

'''Está pensando en comprar una casa y quiere hacerse una idea de cuánto gastará, en función del número de dormitorios y baños. 
Estás tratando de decidir entre cuatro opciones diferentes:

Opción 1: casa de dos dormitorios y tres baños
Opción 2: casa de tres dormitorios y dos baños
Opción 3: casa de tres dormitorios y tres baños
Opción 4: casa de tres dormitorios y cuatro baños
Utilice la función get_expected_cost() que definió anteriormente para asignar a option_1, option_2, option_3 y option_4 
el costo esperado de cada opción.'''

# Cálculo del costo para cada opción de vivienda
option_1 = get_expected_cost(2, 3)
option_2 = get_expected_cost(3, 2)
option_3 = get_expected_cost(3, 3)
option_4 = get_expected_cost(3,4)

# Mostrar los costos para cada opción
print("casa de dos dormitorios y tres baños:", option_1)
print("casa de tres dormitorios y dos baños", option_2)
print("casa de tres dormitorios y tres baños", option_3)
print("casa de tres dormitorios y cuatro baños", option_4)

