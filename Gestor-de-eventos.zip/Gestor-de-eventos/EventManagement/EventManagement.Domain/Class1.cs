﻿namespace EventManagement.Domain
{
    public class Class1
    {

    }
}
