﻿using Microsoft.AspNetCore.Mvc;
using SimulacionDeRestauranta.Services;

[ApiController]
[Route("api/[controller]")]
public class RestauranteController : ControllerBase
{
    private readonly RestauranteService _servicio;

    public RestauranteController()
    {
        _servicio = new RestauranteService();
    }

    [HttpGet("simular")]
    public IActionResult Simular([FromQuery] int cantidadPedidos)
    {
        var resultado = _servicio.EjecutarSimulacion(cantidadPedidos);
        return Ok(resultado);  // Retorna el resultado de la simulación
    }
}


