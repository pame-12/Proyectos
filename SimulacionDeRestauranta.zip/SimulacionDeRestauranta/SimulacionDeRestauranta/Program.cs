var builder = WebApplication.CreateBuilder(args);

// Configuraci�n de servicios
builder.Services.AddControllersWithViews();
builder.Logging.AddConsole();

var app = builder.Build();

// Habilitar archivos est�ticos
app.UseStaticFiles();

// Definir la ruta predeterminada
app.MapGet("/", () => Results.Redirect("/index.html"));

// Otras rutas si es necesario...
app.MapControllers();

app.Run();

