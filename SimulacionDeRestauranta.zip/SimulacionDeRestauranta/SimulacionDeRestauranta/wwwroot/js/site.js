﻿document.addEventListener("DOMContentLoaded", () => {
    // Obtener el formulario
    const form = document.getElementById("simulacion-form");

    // Escuchar el evento submit del formulario
    form.addEventListener("submit", async (e) => {
        e.preventDefault();  // Prevenir la recarga de la página

        // Obtener el valor de la cantidad de pedidos
        const cantidad = parseInt(document.getElementById("cantidad").value);

        // Validar que la cantidad sea un número válido
        if (isNaN(cantidad) || cantidad <= 0) {
            alert("Por favor, ingresa una cantidad válida de pedidos.");
            return;
        }

        // Mostrar indicador de carga
        const loadingDiv = document.createElement('div');
        loadingDiv.innerHTML = '<div class="loading-spinner"></div><p>Procesando simulación, por favor espere...</p>';
        loadingDiv.className = 'loading-overlay';
        document.body.appendChild(loadingDiv);

        try {
            // Hacer la solicitud al backend
            const response = await fetch(`/api/restaurante/simular?cantidadPedidos=${cantidad}`);
            const resultado = await response.json();

            // Guardar el resultado en localStorage
            localStorage.setItem("resultadoSimulacion", JSON.stringify(resultado));

            // Redirigir a la página de resultados
            window.location.href = "resultados.html";
        } catch (error) {
            alert("Ocurrió un error al ejecutar la simulación.");
            console.error(error);
        }
    });
});


