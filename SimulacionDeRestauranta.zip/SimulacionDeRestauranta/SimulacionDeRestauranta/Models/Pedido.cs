﻿namespace SimulacionDeRestauranta.Models
{
    public class Pedido
    {
        public int Id { get; set; }
        public string Platillo { get; set; }
        public DateTime HoraPedido { get; set; }
        public int TiempoEntrega { get; set; }
        public bool EsGratis { get; set; }
    }
}
