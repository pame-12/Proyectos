﻿using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        Console.WriteLine("Iniciando procesamiento de pedidos...");

        var cts = new CancellationTokenSource();

        
        var procesarPedidos = Task.Run(async () =>
        {
            var pedido1 = ProcesarPedidoAsync(1, cts.Token);
            var pedido2 = ProcesarPedidoAsync(2, cts.Token);

            
            await Task.WhenAny(pedido1, pedido2);
        });

        
        var cancelTask = Task.Run(() =>
        {
            Console.WriteLine("Presiona la tecla 'c' para cancelar o cualquier otra para salir.");
            while (true)
            {
                var key = Console.ReadKey(true).KeyChar;
                if (key == 'c')
                {
                    Console.WriteLine("\n Cancelando pedidos...");
                    cts.Cancel();
                    break;
                }
            }
        });

        
        var completedTask = await Task.WhenAny(procesarPedidos, cancelTask);

        if (completedTask == cancelTask)
        {
            Console.WriteLine("Cancelando pedidos en curso...");
            try
            {
                await procesarPedidos;
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Pedidos cancelados correctamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inesperado: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("Procesamiento completado.");
        }
    }

    static async Task ProcesarPedidoAsync(int idPedido, CancellationToken token)
    {
        Console.WriteLine($"Pedido {idPedido}: Iniciando validación...");

        var validacion = Task.Factory.StartNew(async () =>
        {
            try
            {
                await Task.Delay(1000);
                token.ThrowIfCancellationRequested();
                Console.WriteLine($"Pedido {idPedido}: Validación completada.");
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine($"Pedido {idPedido}: Cancelación detectada en validación.");
                throw;
            }
        }, token, TaskCreationOptions.AttachedToParent, TaskScheduler.Default).Unwrap();

        var pago = validacion.ContinueWith(async t =>
        {
            if (t.IsFaulted || t.IsCanceled)
            {
                Console.WriteLine($"Pedido {idPedido}: Validación fallida. Pedido cancelado.");
                return;
            }

            Console.WriteLine($"Pedido {idPedido}: Procesando pago...");
            await Task.Delay(2000, token); 
            Console.WriteLine($"Pedido {idPedido}: Pago aprobado.");
        }, TaskContinuationOptions.OnlyOnRanToCompletion).Unwrap();

        var envio = pago.ContinueWith(async _ =>
        {
            Console.WriteLine($"Pedido {idPedido}: Enviando pedido...");
            await Task.Delay(1500, token);
            Console.WriteLine($"Pedido {idPedido}: Enviado con éxito.");
        }, TaskContinuationOptions.OnlyOnRanToCompletion).Unwrap();

        var cancelacion = pago.ContinueWith(_ =>
        {
            Console.WriteLine($"Pedido {idPedido}: Pago fallido. Pedido cancelado.");
        }, TaskContinuationOptions.OnlyOnCanceled);

        await envio;
    }
}
