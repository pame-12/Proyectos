# preguntas_respuestas.py
#2023-1668
#Pamela Blanco


# 📌 Calcular probabilidad de coincidencia
def message_probability(user_message, recognized_words, single_response=False, required_words=[]):
    message_certainty = 0
    has_required_words = True

    for word in user_message:
        if word in recognized_words:
            message_certainty += 1

    percentage = float(message_certainty) / float(len(recognized_words)) if recognized_words else 0

    for word in required_words:
        if word not in user_message:
            has_required_words = False

    if has_required_words or single_response:
        return int(percentage * 100)
    else:
        return 0


def cargar_respuestas(message):
    highest_probability = {}

    def response(bot_response, list_of_words, single_response=False, required_words=[]):
        nonlocal highest_probability
        highest_probability[bot_response] = message_probability(
            message, list_of_words, single_response, required_words
        )

    # 📌 Preguntas y variantes sobre ITLA:
    response('El ITLA está ubicado en la Autopista Las Américas, Km. 27, Boca Chica.', 
             ['donde', 'ubicado', 'direccion', 'queda', 'localizacion', 'esta', 'llego', 'ubicacion', 'lugar'])
    
    response('¡Hola! ¿Cómo puedo ayudarte con información sobre el ITLA?', 
             ['hola', 'buenos días', 'buenas tardes', 'hey', 'saludos', 'buenas', 'buen', 'día'])

    response('El teléfono del ITLA es (809) 738-4852.', 
             ['telefono', 'contacto', 'llamar', 'numero', 'comunicarme', 'tell', 'cell'])

    response('El correo institucional del ITLA es info@itla.edu.do.', 
             ['correo', 'email', 'contacto'])

    response('La página web del ITLA es https://itla.edu.do', 
             ['pagina', 'web', 'sitio', 'enlace', 'link'])

    response('Las carreras que ofrece ITLA incluyen: Desarrollo de Software, Redes, Multimedia, Mecatrónica, entre otras.', 
             ['carreras', 'ofrece', 'tecnicaturas', 'cursos', 'formacion', 'programa', 'areas'])

    response('El ITLA ofrece modalidad presencial y virtual en algunos programas.', 
             ['modalidad', 'clases', 'presencial', 'virtual', 'online', 'modalidades', 'horarios'])

    response('El proceso de admisión en ITLA incluye preregistro online, pago de pruebas y evaluación.', 
             ['admision', 'inscripcion', 'registrar', 'matricula'])

    response('El lema del ITLA es "Pasión por la excelencia".', 
             ['lema', 'frase', 'mision'])

    response('El ITLA fue fundado en el año 2000.', 
             ['fundacion', 'cuando', 'ano', 'creo', 'inicio', 'principio', 'abrio'])

    response('El ITLA se especializa en áreas tecnológicas como software, redes, multimedia, seguridad informática y más.', 
             ['especialidad', 'enfoca', 'area'])
    
    response('¡De nada! Si tienes más preguntas, estaré aquí para ayudarte.', 
             ['gracias', 'muchas gracias', 'te agradezco'])

    return highest_probability
