# chatbot_itla.py
#2023-1668
#Pamela Blanco

import re
import random
from preguntas_respuestas import cargar_respuestas

# Función principal para procesar la entrada del usuario
def get_response(user_input):
    """
    Divide la entrada del usuario en palabras clave utilizando una expresión regular
    y verifica cuál es la respuesta más adecuada según las palabras detectadas.
    """
    split_message = re.split(r'\s|[,:;.?!-_]\s*', user_input.lower())
    response = check_all_messages(split_message)
    return response

# 📌 Verificar todas las respuestas posibles
def check_all_messages(message):
    highest_probability = cargar_respuestas(message)
    best_match = max(highest_probability, key=highest_probability.get)
    return unknown() if highest_probability[best_match] < 1 else best_match

# 📌 Respuesta por defecto
def unknown():
    """
    Retorna una respuesta genérica cuando el bot no puede encontrar
    una coincidencia adecuada para el mensaje del usuario.
    """
    responses = [
        '¿Puedes repetir tu pregunta sobre ITLA?',
        'No tengo información sobre eso. Intenta con otra pregunta del ITLA.',
        'Lo siento, no entendí tu duda sobre ITLA.',
        'Por favor, sé más específico sobre el ITLA.',
    ]
    return random.choice(responses)



# 📌 Bucle principal
while True:
    """
    Solicita entrada al usuario, procesa el mensaje y retorna la respuesta del bot.
    """
    print("Bot: " + get_response(input("You: ")))
