﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

class Program
{
    
    static volatile bool ganadorEncontrado = false;

    static async Task Main()
    {
        List<string> motoconchistas = new List<string> { "Motoconchista 1", "Motoconchista 2", "Motoconchista 3", "Motoconchista 4" };
        Dictionary<string, int> posiciones = new Dictionary<string, int>();
        HashSet<string> cancelados = new HashSet<string>();
        Random rand = new Random();

        foreach (var moto in motoconchistas)
        {
            posiciones[moto] = 0;
        }

        Console.WriteLine("¡Comienza la carrera de motoconchistas!");

        var tasks = motoconchistas.Select(moto => Task.Run(() => CarreraMotoconcho(moto, posiciones, cancelados, rand))).ToList();

        await Task.WhenAll(tasks);

        
        if (!ganadorEncontrado && cancelados.Count == motoconchistas.Count)
        {
            Console.WriteLine("\n¡Todos los motoconchistas han sido cancelados! La carrera termina sin ganadores.");
        }
    }

    static async Task CarreraMotoconcho(string moto, Dictionary<string, int> posiciones, HashSet<string> cancelados, Random rand)
    {
        while (true)
        {
           
            if (ganadorEncontrado)
                return;

            
            if (posiciones[moto] >= 500)
            {
                ganadorEncontrado = true; 
                Console.WriteLine($"\n¡{moto} ha ganado la carrera!");
                return;
            }

            
            if (rand.NextDouble() < 0.1)
            {
                Console.WriteLine($"{moto} fue cancelado por robarse el motor o el dinero!");
                cancelados.Add(moto);
                return;
            }

            int avance = 0;
            int accion = rand.Next(4);

            switch (accion)
            {
                case 0: // Acelerar
                    avance = rand.Next(15, 40);
                    if (rand.NextDouble() < 0.1)
                    {
                        avance -= 20;
                        Console.WriteLine($"{moto} cayó en un hoyo y perdió 20 metros!");
                    }
                    break;
                case 1: // Hacer Ziczac
                    avance = rand.Next(10, 30);
                    if (rand.NextDouble() < 0.05)
                    {
                        avance -= 20;
                        Console.WriteLine($"{moto} chocó con otro motoconcho y perdió 20 metros!");
                    }
                    break;
                case 2: // Evadir Amet
                    if (rand.NextDouble() < 0.5)
                    {
                        Console.WriteLine($"{moto} fue detenido por un Amet y perdió 2 segundos!");
                        await Task.Delay(2000);
                        continue;
                    }
                    break;
                case 3: // Lidiar con el Pasajero
                    if (rand.NextDouble() < 0.3)
                    {
                        Console.WriteLine($"{moto} perdió 6 segundos porque el pasajero se cayó!");
                        await Task.Delay(6000);
                        continue;
                    }
                    else
                    {
                        avance = 20;
                    }
                    break;
            }

            
            posiciones[moto] += avance;
            posiciones[moto] = Math.Max(0, posiciones[moto]);
            Console.WriteLine($"{moto} avanzó {avance} metros. Ahora está en {posiciones[moto]} metros.");

           
            await Task.Delay(1000);
        }
    }
}
