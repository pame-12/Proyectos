﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
class CarreraTortugas
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("¡La Carrera de Tortugas Programadoras!");
        Console.WriteLine("¡Que comience la carrera!");
        
        // 1. Crear un CancellationTokenSource
        var cts = new CancellationTokenSource();
        var token = cts.Token;
        Console.WriteLine("Presiona la tecla c para cancelar");
        // 2. Crear una tarea para cada tortuga, usando Task.Factory.StartNew
        Task tortuga1 = Task.Factory.StartNew(() => AvanzarTortuga("Tortuga 1", 7000, token), token);
        Task tortuga2 = Task.Factory.StartNew(() => AvanzarTortuga("Tortuga 2", 5000, token), token);
        Task tortuga3 = Task.Factory.StartNew(() => AvanzarTortuga("Tortuga 3", 9000, token), token);

        // 4. Permitir que el usuario cancele la carrera de una tortuga presionando una tecla
        var cancelTask = Task.Run(() => 
        {
           
            while (true)
            {
                var key = Console.ReadKey().KeyChar;
                if (key == 'c')
                {
                    cts.Cancel();
                    break;

                }

            }
        });

        await Task.WhenAny(Task.WhenAll(tortuga1, tortuga2, tortuga3), cancelTask);
        if (cts.IsCancellationRequested)
        {
            Console.WriteLine("Carrera Cancelada. ");
        }
        else
        {
            Console.WriteLine("La carrera ha terminado. ");
        }

        Console.WriteLine("Presiona cualquier tecla para salir.");
        Console.ReadKey();
    }


    
    

    static async Task AvanzarTortuga(string nombreTortuga, int tiempoLimite, CancellationToken token)
    {
        try
        {
            for (int i = 0; i <= 100; i += 10)
            {
                 
                Console.WriteLine($"{nombreTortuga} está avanzando: {i}%");

                
                await Task.Delay(tiempoLimite / 10, token);
            }
            Console.WriteLine($"{nombreTortuga} ha llegado a la meta.");
        }

        catch (OperationCanceledException)
        {
            Console.WriteLine($"{nombreTortuga} ha sido descalificada por el juez.");
        }
    }

}

