namespace SimulacionDeRestauranta.Models
{
    public class SimulacionData
    {
        public int CantidadPeticiones { get; set; }
    }
}