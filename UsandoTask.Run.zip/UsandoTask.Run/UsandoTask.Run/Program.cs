﻿using System;
using System.Threading.Tasks;
namespace Task_Run
{
    class Program
    {
        static async Task Main()
        {
            Console.WriteLine("Tarea iniciada.");
            Task<long> task = Task.Run(() =>
            {
                long sum = 0;
                Console.WriteLine($"Iniciando");
                for (long i = 0; i < 100000000; i++)
                {
                    sum += i * 2;

                }
                return sum;
            });

            long resultado = await task;

            Console.WriteLine($"Se ha finalizado con la suma total a: {resultado}");

            Console.WriteLine("Tarea completada.");
        }
    }
}
